﻿namespace Valoracion1.Modelo 
{
    public class PuntoDeVenta
    {
        public int Id { get; set; }
        public string Nombre { get; set; } = "";
        public string Zona { get; set; } = "";
        public string Direccion { get; set; } = "";
        public double Latitud { get; set; }
        public double Longitud { get; set; }
    }
}