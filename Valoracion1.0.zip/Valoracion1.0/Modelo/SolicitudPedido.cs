﻿namespace Valoracion1.Modelo
{
    public class SolicitudPedido
    {
        public int Id { get; set; }
        public DateOnly FechaPedido { get; set; }
        public TimeOnly HoraPedido { get; set; }
        public string NombreSolicitante { get; set; } = "";
        public Producto? Producto { get; set; }
        public int CantidadSolicitada { get; set; }
        public decimal PrecioVenta { get; set; }
        public PuntoDeVenta? PuntoDeVenta { get; set; }
        public string TipoPago { get; set; } = "Efectivo";

        public decimal Cobro => CantidadSolicitada * PrecioVenta;
    }
}