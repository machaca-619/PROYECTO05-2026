<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Soporte Sistema Tasy</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <section id="login" class="login">
    <div class="login-card">
      <h1>Sistema de Soporte Tasy</h1>
      <p>Ingreso solo para responsables de soporte</p>

      <form id="formLogin">
        <label>Código de soporte</label>
        <input type="text" id="codigo" placeholder="Ej: SOP001" required>

        <label>Contraseña</label>
        <input type="password" id="contrasena" placeholder="Ingrese su contraseña" required>

        <button type="submit">Ingresar</button>
      </form>
    </div>
  </section>

  <section id="sistema" class="oculto">
    <header>
      <h1>Registro de Soporte - Sistema Tasy</h1>
      <p id="soporteActivo"></p>
    </header>

    <nav>
      <a href="#registro">Registrar atención</a>
      <a href="#tabla">Reportes</a>
      <button onclick="cerrarSesion()" class="salir">Cerrar sesión</button>
    </nav>

    <main>
      <section id="registro" class="card">
        <h2>Registrar Atención / Incidencia</h2>

        <form id="formReporte">
          <h3>Datos de la persona atendida</h3>

          <label>Fecha</label>
          <input type="date" id="fecha" required>

          <label>Sector / Área</label>
          <input type="text" id="sector" placeholder="Ej: Emergencia, Farmacia, Admisión" required>

          <label>Turno</label>
          <select id="turno" required>
            <option value="">Seleccione</option>
            <option>Mañana</option>
            <option>Tarde</option>
            <option>Noche</option>
          </select>

          <label>Tipo de usuario atendido</label>
          <select id="tipoUsuarioAtendido" required>
            <option value="">Seleccione</option>
            <option>Médico</option>
            <option>Enfermera</option>
            <option>Personal Administrativo</option>
            <option>Farmacia</option>
            <option>Laboratorio</option>
            <option>Otro</option>
          </select>

          <label>Nombre de la persona atendida</label>
          <input type="text" id="nombreUsuarioAtendido" placeholder="Nombre completo" required>

          <h3>Datos del soporte realizado</h3>

          <label>Responsable de soporte</label>
          <input type="text" id="responsableSoporte" readonly>

          <label>Tipo de atención</label>
          <select id="tipoAtencion" required>
            <option value="">Seleccione</option>
            <option>Presencial</option>
            <option>Remoto</option>
            <option>Telefónico</option>
          </select>

          <label>Incidencia / Problema reportado</label>
          <input type="text" id="incidencia" placeholder="Ej: Error al ingresar, módulo bloqueado, contraseña" required>

          <label>Solución aplicada</label>
          <textarea id="solucion" rows="4" placeholder="Describa la solución aplicada" required></textarea>

          <label>Tipo de incidencia</label>
          <select id="tipoIncidencia" required>
            <option value="">Seleccione</option>
            <option>Sistema Tasy</option>
            <option>Desconocimiento del flujo</option>
            <option>Restablecimiento de contraseña</option>
            <option>Problema de acceso</option>
            <option>Error del sistema</option>
            <option>Otros</option>
          </select>

          <label>Estado</label>
          <select id="estado" required>
            <option>Pendiente</option>
            <option>En proceso</option>
            <option>Solucionado</option>
          </select>

          <button type="submit">Guardar reporte</button>
          <button type="reset" class="secundario">Limpiar</button>
        </form>
      </section>

      <section id="tabla" class="card">
        <h2>Reportes Registrados</h2>

        <div class="acciones">
          <input type="text" id="buscar" placeholder="Buscar por persona, sector, incidencia o soporte">
          <button onclick="exportarCSV()">Exportar CSV</button>
          <button onclick="borrarReportes()" class="peligro">Borrar reportes</button>
        </div>

        <div class="tabla-contenedor">
          <table>
            <thead>
              <tr>
                <th>Fecha</th>
                <th>Sector</th>
                <th>Turno</th>
                <th>Usuario atendido</th>
                <th>Tipo usuario</th>
                <th>Responsable soporte</th>
                <th>Tipo atención</th>
                <th>Incidencia</th>
                <th>Solución</th>
                <th>Tipo incidencia</th>
                <th>Estado</th>
              </tr>
            </thead>
            <tbody id="tablaReportes"></tbody>
          </table>
        </div>
      </section>
    </main>
  </section>

  <script src="script.js"></script>
</body>
</html>
