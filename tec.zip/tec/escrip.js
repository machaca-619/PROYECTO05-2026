/* ========================= */
/* INFORMES Y DASHBOARD */
/* ========================= */

function contarPorCampo(array, campo) {

  const conteo = {};

  array.forEach(item => {

    const valor = item[campo];

    if (!conteo[valor]) {
      conteo[valor] = 0;
    }

    conteo[valor]++;

  });

  return conteo;
}

function obtenerMayor(objeto) {

  let mayor = "";
  let cantidad = 0;

  for (let key in objeto) {

    if (objeto[key] > cantidad) {
      mayor = key;
      cantidad = objeto[key];
    }
  }

  return mayor;
}

function cargarDashboard() {

  /* ========================= */
  /* SOPORTES */
  /* ========================= */

  document.getElementById("totalSoportes").textContent =
    reportes.length;

  const areas = contarPorCampo(reportes, "sector");
  const operadores = contarPorCampo(reportes, "responsableSoporte");
  const incidencias = contarPorCampo(reportes, "tipoIncidencia");
  const estados = contarPorCampo(reportes, "estado");

  document.getElementById("areaMasSoporte").textContent =
    obtenerMayor(areas);

  document.getElementById("operadorActivo").textContent =
    obtenerMayor(operadores);

  document.getElementById("incidenciaFrecuente").textContent =
    obtenerMayor(incidencias);

  /* ========================= */
  /* GRAFICA AREAS */
  /* ========================= */

  new Chart(document.getElementById("graficaAreas"), {

    type: "pie",

    data: {
      labels: Object.keys(areas),
      datasets: [{
        data: Object.values(areas),
        backgroundColor: [
          "#0b3d91",
          "#1976d2",
          "#42a5f5",
          "#64b5f6",
          "#90caf9"
        ]
      }]
    }

  });

  /* ========================= */
  /* GRAFICA OPERADORES */
  /* ========================= */

  new Chart(document.getElementById("graficaOperadores"), {

    type: "bar",

    data: {
      labels: Object.keys(operadores),
      datasets: [{
        label: "Cantidad",
        data: Object.values(operadores),
        backgroundColor: "#0b3d91"
      }]
    }

  });

  /* ========================= */
  /* GRAFICA ESTADOS */
  /* ========================= */

  new Chart(document.getElementById("graficaEstados"), {

    type: "doughnut",

    data: {
      labels: Object.keys(estados),
      datasets: [{
        data: Object.values(estados),
        backgroundColor: [
          "#28a745",
          "#ffc107",
          "#dc3545"
        ]
      }]
    }

  });

  /* ========================= */
  /* GRAFICA INCIDENCIAS */
  /* ========================= */

  new Chart(document.getElementById("graficaIncidencias"), {

    type: "bar",

    data: {
      labels: Object.keys(incidencias),
      datasets: [{
        label: "Cantidad",
        data: Object.values(incidencias),
        backgroundColor: "#1976d2"
      }]
    }

  });

  /* ========================= */
  /* CAPACITACIONES */
  /* ========================= */

  const capacitaciones =
    JSON.parse(localStorage.getItem("capacitacionesTasy")) || [];

  document.getElementById("totalCapacitaciones").textContent =
    capacitaciones.length;

  const areasCap = contarPorCampo(capacitaciones, "area");
  const responsablesCap = contarPorCampo(capacitaciones, "responsable");
  const modalidadCap = contarPorCampo(capacitaciones, "modalidad");

  document.getElementById("areaCapacitada").textContent =
    obtenerMayor(areasCap);

  document.getElementById("responsableCapacitacion").textContent =
    obtenerMayor(responsablesCap);

  document.getElementById("modalidadFrecuente").textContent =
    obtenerMayor(modalidadCap);

  /* ========================= */
  /* GRAFICA CAPACITACIONES */
  /* ========================= */

  new Chart(document.getElementById("graficaCapacitaciones"), {

    type: "pie",

    data: {
      labels: Object.keys(areasCap),
      datasets: [{
        data: Object.values(areasCap),
        backgroundColor: [
          "#0b3d91",
          "#1976d2",
          "#42a5f5",
          "#64b5f6"
        ]
      }]
    }

  });

  /* ========================= */
  /* GRAFICA MODALIDAD */
  /* ========================= */

  new Chart(document.getElementById("graficaModalidad"), {

    type: "bar",

    data: {
      labels: Object.keys(modalidadCap),
      datasets: [{
        label: "Cantidad",
        data: Object.values(modalidadCap),
        backgroundColor: "#0b3d91"
      }]
    }

  });

}

/* ========================= */
/* EJECUTAR DASHBOARD */
/* ========================= */

cargarDashboard();