// SOLO ESTAS 4 PERSONAS PUEDEN INGRESAR AL SISTEMA
// Cambia nombres, códigos y contraseñas según corresponda.
const responsablesSoporte = [
  {
    codigo: "Jaime",
    contrasena: "12345",
    nombre: "Jaime Maldonado Ibañez"
  },
  {
    codigo: "Carlos",
    contrasena: "12345",
    nombre: "Responsable Soporte 2"
  },
  {
    codigo: "Andres",
    contrasena: "12345",
    nombre: "Responsable Soporte 3"
  },
  {
    codigo: "Marco",
    contrasena: "12345",
    nombre: "Responsable Soporte 4"
  }
];

let reportes = JSON.parse(localStorage.getItem("reportesTasy")) || [];
let soporteActual = JSON.parse(localStorage.getItem("soporteActualTasy")) || null;

const login = document.getElementById("login");
const sistema = document.getElementById("sistema");
const formLogin = document.getElementById("formLogin");
const formReporte = document.getElementById("formReporte");
const soporteActivo = document.getElementById("soporteActivo");
const tablaReportes = document.getElementById("tablaReportes");
const buscar = document.getElementById("buscar");

formLogin.addEventListener("submit", function(e) {
  e.preventDefault();

  const codigoIngresado = document.getElementById("codigo").value;
  const contrasenaIngresada = document.getElementById("contrasena").value;

  const soporte = responsablesSoporte.find(s =>
    s.codigo === codigoIngresado && s.contrasena === contrasenaIngresada
  );

  if (!soporte) {
    alert("Código o contraseña incorrectos.");
    return;
  }

  soporteActual = soporte;
  localStorage.setItem("soporteActualTasy", JSON.stringify(soporteActual));

  formLogin.reset();
  verificarSesion();
});

function verificarSesion() {
  if (soporteActual) {
    login.classList.add("oculto");
    sistema.classList.remove("oculto");

    soporteActivo.textContent =
      "Responsable activo: " + soporteActual.nombre +
      " | Código: " + soporteActual.codigo;

    document.getElementById("responsableSoporte").value = soporteActual.nombre;
  } else {
    login.classList.remove("oculto");
    sistema.classList.add("oculto");
  }
}

formReporte.addEventListener("submit", function(e) {
  e.preventDefault();

  const reporte = {
    fecha: document.getElementById("fecha").value,
    sector: document.getElementById("sector").value,
    turno: document.getElementById("turno").value,
    tipoUsuarioAtendido: document.getElementById("tipoUsuarioAtendido").value,
    nombreUsuarioAtendido: document.getElementById("nombreUsuarioAtendido").value,
    responsableSoporte: soporteActual.nombre,
    tipoAtencion: document.getElementById("tipoAtencion").value,
    incidencia: document.getElementById("incidencia").value,
    solucion: document.getElementById("solucion").value,
    tipoIncidencia: document.getElementById("tipoIncidencia").value,
    estado: document.getElementById("estado").value
  };

  reportes.push(reporte);
  localStorage.setItem("reportesTasy", JSON.stringify(reportes));

  formReporte.reset();
  document.getElementById("responsableSoporte").value = soporteActual.nombre;

  mostrarReportes();
  alert("Reporte guardado correctamente.");
});

buscar.addEventListener("input", mostrarReportes);

function mostrarReportes() {
  tablaReportes.innerHTML = "";
  const filtro = buscar.value.toLowerCase();

  reportes
    .filter(r =>
      r.sector.toLowerCase().includes(filtro) ||
      r.nombreUsuarioAtendido.toLowerCase().includes(filtro) ||
      r.incidencia.toLowerCase().includes(filtro) ||
      r.responsableSoporte.toLowerCase().includes(filtro)
    )
    .forEach((r) => {
      const fila = document.createElement("tr");
      fila.innerHTML = `
        <td>${r.fecha}</td>
        <td>${r.sector}</td>
        <td>${r.turno}</td>
        <td>${r.nombreUsuarioAtendido}</td>
        <td>${r.tipoUsuarioAtendido}</td>
        <td>${r.responsableSoporte}</td>
        <td>${r.tipoAtencion}</td>
        <td>${r.incidencia}</td>
        <td>${r.solucion}</td>
        <td>${r.tipoIncidencia}</td>
        <td>${r.estado}</td>
      `;
      tablaReportes.appendChild(fila);
    });
}

function exportarCSV() {
  let csv = "Fecha,Sector,Turno,Usuario Atendido,Tipo Usuario,Responsable Soporte,Tipo Atención,Incidencia,Solución,Tipo Incidencia,Estado\n";

  reportes.forEach(r => {
    csv += `"${r.fecha}","${r.sector}","${r.turno}","${r.nombreUsuarioAtendido}","${r.tipoUsuarioAtendido}","${r.responsableSoporte}","${r.tipoAtencion}","${r.incidencia}","${r.solucion}","${r.tipoIncidencia}","${r.estado}"\n`;
  });

  const archivo = new Blob([csv], { type: "text/csv" });
  const enlace = document.createElement("a");
  enlace.href = URL.createObjectURL(archivo);
  enlace.download = "Reporte_Tasy_Soporte.csv";
  enlace.click();
}

function borrarReportes() {
  if (confirm("¿Seguro que desea borrar todos los reportes?")) {
    reportes = [];
    localStorage.removeItem("reportesTasy");
    mostrarReportes();
  }
}

function cerrarSesion() {
  localStorage.removeItem("soporteActualTasy");
  soporteActual = null;
  verificarSesion();
}

verificarSesion();
mostrarReportes();
