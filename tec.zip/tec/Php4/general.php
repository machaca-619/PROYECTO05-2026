<?php
include_once("\wamp64\www\php4\paginas\clases2.php");

$Obj = new CEMENTERIO();
$Obj->Mostrar();

echo "<br><br><center><A href='/tecnologia/php4/index5.php'>MENU PRINCIPAL</A></center>";
?>