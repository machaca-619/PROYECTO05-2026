<html>
<head>
    <script>
        function consulta1(form1)
        {
            geneleg = form1.genero.value;
            document.location.href = "/php04/paginas/consulta1.php?genero="+geneleg;
        }
        function consulta2(form1)
        {
            caueleg = form1.causa.value;
            document.location.href = "/tecnologia/php04/paginas/consulta2.php?causa="+caueleg;
        }
    </script>
</head>

<body>
        <H1><CENTER>CONSULTAS</CENTER></H1>
        <HR>
    <BR><BR>
    <form name = form1>
        <TABle BORDER=2 align=CENTER  width = 70%  >
            <TR align=CENTER>
                <td  bgcolor=RED>
                <label>
                <B>CONSULTA 1:</B> 
                <BR>ELIJA UN GENERO<BR>
                <input type="radio" name="genero" value = "HOMBRE">HOMBRE
                <input type="radio" name="genero" value = "MUJER">MUJER
                </label>
                <BR><BR> <input type=button value="PROCESAR" onclick="consulta1(form1)"><BR><BR>
                </td>

                <td bgcolor=YELLOW>
                    <label><br>
                    <B>CONSULTA 2:</B>
                    <BR>ELIJA UNA CAUSA<br>
     <input type="radio" name="causa" value = "ENFERMEDAD">ENFERMEDAD
     <input type="radio" name="causa" value = "ASESINATO">ASESINATO
     <input type="radio" name="causa" value = "COVID 19">COVID 19
     <input type="radio" name="causa" value = "NORMAL">NORMAL
                    </label>
<BR><BR> <input type=button value="PROCESAR" onclick="consulta2(form1)"> <BR><BR>
                </td>
            </TR>

            <TR ALIGN=CENTER>
                <td bgcolor=GREEN>
                <B>CONSULTA 3:</B>
                </td>
                <td>
                <B>CONSULTA 4:</B>
                </td>
            </TR>
        </TABle>
</form>
<BR><BR>
"<br><br><center><A href='/tecnologia/php4/index5.php'>MENU PRINCIPAL</A></center>";
</BODY>
</html>