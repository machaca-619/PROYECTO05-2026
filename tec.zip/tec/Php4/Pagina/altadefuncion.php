<html>
<h1><center>ENTIERRO REGISTRADO</center></h1>
<hr>
<?php
$FEnt = $_REQUEST['fechaentierro'];
$Cau = $_REQUEST['causa'];
$Nom = $_REQUEST['nombre'];
$Dep = $_REQUEST['dependientes'];
$Gen = $_REQUEST['genero'];

if(isset($_REQUEST['nicho']))
  $Nic = "SI";
  else
  $Nic = "NO";

/*echo $FEnt."<br>";
echo $Cau."<br>";
echo $Nom."<br>";
echo $Dep."<br>";
echo $Gen."<br>";
echo $Nic."<br>";*/


include_once("/wamp64/www/php4/paginas/clases2.php");

$Obj = new CEMENTERIO();
$Obj->Altas($FEnt, $Cau, $Nom,$Dep,$Gen,$Nic);
$Obj->Mostrar();

echo "<br><br><center><A href='/tecnologia/php4/index5.php'>MENU PRINCIPAL</A></center>";
?>
</html>