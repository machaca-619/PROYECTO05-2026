<html>
<body>

<center><h1>CEMENTERIO</h1></center>
<HR>
<form method = "post" action="/tecnologia/php4/paginas/altadefuncion.php">
<?php
$fecha_actual = date('Y-m-d'); 
?>

<table border = 5 bgcolor=yellow align=center>
<tr align=center bgcolor=pink>
<td colspan=2>DATOS DE UN ENTIERRO</td>
</tr>
<tr align=center>
<td>FECHA DE ENTIERRO<br>
<input type=date name="fechaentierro"> </td>
<td>
CAUSA<br>
<input type="radio" name="causa" value = "ENFERMEDAD">ENFERMEDAD
<input type="radio" name="causa" value = "ASESINATO">ASESINATO
<input type="radio" name="causa" value = "COVID 19">COVID 19
<input type="radio" name="causa" value = "NORMAL">NORMAL

</td>
</tr>
<tr align=center>
<td>
NOMBRE DEL DIFUNTO<BR>
<input type=text name = "nombre">
</td>

<td>
NUMERO DE DEPENDIENTES QUE DEJA<BR>
<input type=number name = "dependientes">
</td>
</tr>

<tr align=center>
<td>
GENERO<BR>
<input type="radio" name="genero" value = "HOMBRE">HOMBRE
<input type="radio" name="genero" value = "MUJER">MUJER
</td>

<td>
TIENE NICHO?<BR>
<input type=checkbox name="nicho">SI
</td>

</tr>

<tr align=center>
<td colspan=2>
<input type="submit" value="GUARDAR">
</td>
</tr>
</table>
</form>

</body>
</html>