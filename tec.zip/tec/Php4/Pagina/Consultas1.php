<html>
    <boby>
    <button><A href="/tecnologia/php4/index5.php">HOME</A></button>
    <button><A href="/tecnologia/php4/paginas/consultas.php">BACK</A></button>
    <BR><BR>
    </BODY>
</html>

<?php
$geneleg = $_REQUEST["genero"];
//echo $geneleg;

include_once("/wamp64/www/php4/paginas/clases2.php");

$Obj = new CEMENTERIO();
$Obj->Consulta1($geneleg);
?>