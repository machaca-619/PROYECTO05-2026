<html>
    <boby>
    <button><A href="/tecnologia/php4/index5.php">HOME</A></button>
    <button><A href="/tecnologia/php4/paginas/consultas.php">BACK</A></button>
    <BR><BR>
    </BODY>
</html>

<?php
$caueleg = $_REQUEST["causa"];
//echo $caueleg;

include_once("/wamp64/www/php04/paginas/clases.php");

$Obj = new CEMENTERIO();
$Obj->Consulta2($caueleg);
?>