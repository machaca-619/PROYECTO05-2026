<html>
<head>
<link rel="stylesheet" href="\tecnologia\php4\Estilos\estilo.css">
</head>
<body>
<header>

<table width=100%>
<tr>
<td align=center><img src="\Tecnologia\php4\Imagenes\logo.jpeg" width=100 height=100></td>
<td ><marquee behavior=alternate >
<font size=40 face="Broadway2,Castellar">TECNOLOGIA WEB I</font>
</marquee></td>
</tr>
</table>
</header>


<nav id="menu">
<ul align=center>
<li><a href="/Tecnologia/php4/pagina/entierro.php">REGISTRAR ENTIERROS</a>
<li><a href="/Tecnologia/php4/pagina/general.php">LISTADO GENERAL</a>
<li><a href="/Tecnologia/php4/pagina/consultas.php">CONSULTAS</a> 
</ul>
</nav>

<div id="contenedor">
 <section>
       <article>
        <h1>
        <center>ARTICULO 1.- Instalación y configuración de entornos web</CENTER>
        </h1>
        <BR>

        <h3>
        JAVA SCRIPT.- DEBE IR A LA PAGINA DE FORMULARIO CON TABLA Y JAVA SCRIPT
        </H3>
        <BR>
        <BR>  
       </article>

       <article>
       <H1><center>ARTICULO 2.-    Fundamentos de lenguajes Backend </center></H1>
       <H2>Pagina 2:<br>
       Contendra Tabla, formularios y java script.  <br>
        <br>
       </H2>
       </article>

       <article>
       <H1><center>ARTICULO 3.-    Servidor DNS </center></H1>
       <H2>Pagina 3.- Los datos a ingresar son: <br>
       Nombre del Producto, cantidad, el precio unitario.
       <br>
       <br>
       </H2>
       </article>


     <article id="articulo4">
<H1><center>ARTICULO 4.-    Servidor de TELNET y SSH </center></H1>
       <H2>Pagina 4.- El boton cobro debe:<br>
       Cobrar, tomando en cuenta la cantidad y el precio unitario.
       <br>
       <br>
       </H2>
      </article>

 </section>

<aside align=center>
    <p><h2>SIGUEME EN</h2></p>
    <a href="http://www.facebook.com">
    <img src="/tecnologia/php4/Imagenes/face.png" width=100 height=100>
    </a>
    <br><BR><br>
  
    <a href="http://www.instagram.com">
    <img src="/tecnologia/php4/Imagenes/instagram.jpg" width=180 height=100>
    </a>
    <BR><BR><br>

    <a href="http://www.twitter.com">
    <img src="/tecnologia/php4/Imagenes/twitter.png" width=100 height=100>
    </a>
    <BR><br><br>

    <a href="http://www.youtube.com">
    <img src="/tecnologia/php4/Imagenes/youtube.png" width=100 height=100>
    </a>
  <br><BR>
</aside>
</div>

<footer align=center>
<center><h1><marquee>COPY RIGHT - 2026</marquee> </h1></center>
</footer>
</body>
</html>