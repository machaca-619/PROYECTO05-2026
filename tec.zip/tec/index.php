<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Agenda de Capacitaciones - Sistema Tasy</title>

  <style>
    *{
      margin:0;
      padding:0;
      box-sizing:border-box;
      font-family: Arial, Helvetica, sans-serif;
    }

    body{
      background:#f4f6f9;
      color:#333;
    }

    header{
      background:#005792;
      color:white;
      padding:20px;
      text-align:center;
    }

    nav{
      background:#003f63;
      padding:15px;
      display:flex;
      justify-content:center;
      gap:20px;
      flex-wrap:wrap;
    }

    nav a{
      color:white;
      text-decoration:none;
      font-weight:bold;
    }

    main{
      width:90%;
      max-width:1200px;
      margin:30px auto;
    }

    .card{
      background:white;
      padding:25px;
      border-radius:10px;
      margin-bottom:25px;
      box-shadow:0 2px 8px rgba(0,0,0,0.1);
    }

    h2{
      margin-bottom:20px;
      color:#005792;
    }

    form{
      display:grid;
      grid-template-columns:1fr 1fr;
      gap:15px;
    }

    form .full{
      grid-column:1/3;
    }

    label{
      font-weight:bold;
      margin-bottom:5px;
      display:block;
    }

    input,
    select,
    textarea{
      width:100%;
      padding:10px;
      border:1px solid #ccc;
      border-radius:6px;
    }

    textarea{
      resize:vertical;
    }

    button{
      background:#005792;
      color:white;
      border:none;
      padding:12px;
      border-radius:6px;
      cursor:pointer;
      font-weight:bold;
    }

    button:hover{
      background:#003f63;
    }

    table{
      width:100%;
      border-collapse:collapse;
      margin-top:20px;
    }

    table th,
    table td{
      border:1px solid #ddd;
      padding:12px;
      text-align:left;
    }

    table th{
      background:#005792;
      color:white;
    }

    .materiales{
      display:grid;
      grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
      gap:20px;
    }

    .material-card{
      border:1px solid #ddd;
      padding:20px;
      border-radius:8px;
      background:#fafafa;
    }

    .material-card h3{
      margin-bottom:10px;
      color:#005792;
    }

    .material-card a{
      display:inline-block;
      margin-top:10px;
      color:#005792;
      font-weight:bold;
      text-decoration:none;
    }

    @media(max-width:768px){

      form{
        grid-template-columns:1fr;
      }

      form .full{
        grid-column:1/2;
      }

      nav{
        flex-direction:column;
        align-items:center;
      }
    }
  </style>
</head>

<body>

  <header>
    <h1>Agenda de Capacitaciones - Sistema Tasy</h1>
    <p>Gestión de capacitaciones, manuales y guías de uso</p>
  </header>

  <nav>
    <a href="#registro">Registrar capacitación</a>
    <a href="#agenda">Agenda programada</a>
    <a href="#materiales">Materiales de apoyo</a>
  </nav>

  <main>

    <section id="registro" class="card">

      <h2>Registro de Capacitación</h2>

      <form>

        <div>
          <label>Fecha</label>
          <input type="date" required>
        </div>

        <div>
          <label>Hora</label>
          <input type="time" required>
        </div>

        <div>
          <label>Área / Sector</label>
          <input type="text" placeholder="Ej: Emergencia, Farmacia" required>
        </div>

        <div>
          <label>Responsable de capacitación</label>
          <input type="text" placeholder="Nombre del capacitador" required>
        </div>

        <div>
          <label>Tipo de personal</label>
          <select required>
            <option value="">Seleccione</option>
            <option>Médicos</option>
            <option>Enfermería</option>
            <option>Administrativos</option>
            <option>Farmacia</option>
            <option>Laboratorio</option>
            <option>Otros</option>
          </select>
        </div>

        <div>
          <label>Modalidad</label>
          <select required>
            <option value="">Seleccione</option>
            <option>Presencial</option>
            <option>Virtual</option>
            <option>Mixta</option>
          </select>
        </div>

        <div class="full">
          <label>Tema de capacitación</label>
          <input type="text" placeholder="Ej: Uso del módulo de farmacia en Tasy" required>
        </div>

        <div class="full">
          <label>Descripción</label>
          <textarea rows="4" placeholder="Detalle de la capacitación"></textarea>
        </div>

        <div class="full">
          <button type="submit">Guardar capacitación</button>
        </div>

      </form>

    </section>

    <section id="agenda" class="card">

      <h2>Agenda de Capacitaciones Programadas</h2>

      <table>

        <thead>
          <tr>
            <th>Fecha</th>
            <th>Hora</th>
            <th>Área</th>
            <th>Tema</th>
            <th>Responsable</th>
            <th>Modalidad</th>
          </tr>
        </thead>

        <tbody>

          <tr>
            <td>25/05/2026</td>
            <td>08:00</td>
            <td>Emergencia</td>
            <td>Ingreso de pacientes en Tasy</td>
            <td>Juan Pérez</td>
            <td>Presencial</td>
          </tr>

          <tr>
            <td>26/05/2026</td>
            <td>14:00</td>
            <td>Farmacia</td>
            <td>Manejo de inventario</td>
            <td>María López</td>
            <td>Virtual</td>
          </tr>

        </tbody>

      </table>

    </section>

    <section id="materiales" class="card">

      <h2>Materiales de Capacitación</h2>

      <div class="materiales">

        <div class="material-card">
          <h3>Manual de Usuarios</h3>
          <p>Guía básica para el uso del sistema Tasy.</p>
          <a href="#">Ver manual</a>
        </div>

        <div class="material-card">
          <h3>Tutorial de Admisión</h3>
          <p>Procedimiento para registrar pacientes.</p>
          <a href="#">Ver tutorial</a>
        </div>

        <div class="material-card">
          <h3>Guía de Farmacia</h3>
          <p>Uso correcto del módulo de farmacia.</p>
          <a href="#">Ver guía</a>
        </div>

      </div>

    </section>

  </main>

</body>
</html>