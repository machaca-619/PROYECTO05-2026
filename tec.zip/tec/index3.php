<!-- ========================= -->
<!-- MODULO INFORMES -->
<!-- CONEXIÓN REAL DEL SISTEMA -->
<!-- CSS: estilo.css -->
<!-- JS: escrip.js -->
<!-- DATOS: reportesTasy -->
<!-- ORIGEN: soporte.html -->
<!-- ========================= -->

<link rel="stylesheet" href="estilo.css">
<script src="script.js"></script>

<section id="informes" class="card">

  <h2>Dashboard de Informes y Estadísticas</h2>

  <div class="estadisticas">

    <div class="estadistica-card">
      <h3>Total Soportes</h3>
      <p id="totalSoportes">0</p>
    </div>

    <div class="estadistica-card">
      <h3>Área con más soporte</h3>
      <p id="areaMasSoporte">-</p>
    </div>

    <div class="estadistica-card">
      <h3>Operador más activo</h3>
      <p id="operadorActivo">-</p>
    </div>

    <div class="estadistica-card">
      <h3>Incidencia más frecuente</h3>
      <p id="incidenciaFrecuente">-</p>
    </div>

  </div>

  <div class="graficas">

    <div class="grafica-box">
      <h3>Soportes por Área</h3>
      <canvas id="graficaAreas"></canvas>
    </div>

    <div class="grafica-box">
      <h3>Soportes por Operador</h3>
      <canvas id="graficaOperadores"></canvas>
    </div>

    <div class="grafica-box">
      <h3>Estados de Incidencias</h3>
      <canvas id="graficaEstados"></canvas>
    </div>

    <div class="grafica-box">
      <h3>Tipos de Incidencia</h3>
      <canvas id="graficaIncidencias"></canvas>
    </div>

  </div>

</section>


<!-- ========================= -->
<!-- MODULO INFORMES CAPACITACION -->
<!-- CONEXIÓN REAL DEL SISTEMA -->
<!-- CSS: estilo.css -->
<!-- JS: escrip.js -->
<!-- DATOS: capacitacionesTasy -->
<!-- ORIGEN: capacitacion.html -->
<!-- ========================= -->

<section id="informesCapacitacion" class="card">

  <h2>Informes de Capacitaciones</h2>

  <div class="estadisticas">

    <div class="estadistica-card">
      <h3>Total Capacitaciones</h3>
      <p id="totalCapacitaciones">0</p>
    </div>

    <div class="estadistica-card">
      <h3>Área más capacitada</h3>
      <p id="areaCapacitada">-</p>
    </div>

    <div class="estadistica-card">
      <h3>Responsable principal</h3>
      <p id="responsableCapacitacion">-</p>
    </div>

    <div class="estadistica-card">
      <h3>Modalidad más usada</h3>
      <p id="modalidadFrecuente">-</p>
    </div>

  </div>

  <div class="graficas">

    <div class="grafica-box">
      <h3>Capacitaciones por Área</h3>
      <canvas id="graficaCapacitaciones"></canvas>
    </div>

    <div class="grafica-box">
      <h3>Modalidades</h3>
      <canvas id="graficaModalidad"></canvas>
    </div>

  </div>

</section>

<!-- ========================= -->
<!-- CONEXIÓN GLOBAL DEL SISTEMA -->
<!-- ========================= -->

<script src="escrip.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>