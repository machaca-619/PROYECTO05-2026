<?php
class CEMENTERIO{

   public function Conectando(){
        return mysqli_connect("localhost","root","","bdcementerio");
   }

        public function Titulos(){
        echo "<Table border=2 align=center>";
        echo "<TR align=center>";
        echo "<th>CODIGO</th> <th>FECHA ENTIERRO</th> <th>CAUSA</th> 
        <th>NOMBRE</th> <th>DEPENDIENTES</th> <th>GENERO</th> <th>NICHO</th>";
        echo "</TR>";
    }

    public function MostrarRegistro($reg){
        echo "<TR><td>$reg[codent]</td> <td>$reg[fechaent]</td> <td>$reg[causa]</td> 
        <td>$reg[nombre]</td> <td>$reg[dependientes]</td> <td>$reg[genero]</td>
        <td>$reg[nicho]</td>";
        echo "</TR>";
    }

public function Mostrar(){
        echo "<h1><center>LISTADO GENERAL DE ENTIERROS</h1></center>";

        $Conex = $this->Conectando() or die ("Problemas de Conexion");
        $sql = "select codent, fechaent, causa, nombre, dependientes, genero, nicho
         from entierr";
        $Tabla = mysqli_query($Conex,$sql) or die ("Problemas de Consulta");
        $this->Titulos();
        
        while($reg=mysqli_fetch_array($Tabla)){
              $this->MostrarRegistro($reg);
        }
        echo "</table>";
        mysqli_close($Conex);
    }

public function Altas($FEnt, $Cau, $Nom, $Dep,$Gen,$Nic)
  {
     $Conex = $this->Conectando() or die ("Problema de conexion");
     $sql = "insert into entierros (FechaEnt, Causa, Nombre, Dependientes, 
     Genero, Nicho) values ('$FEnt','$Cau','$Nom', '$Dep','$Gen', '$Nic')";
     mysqli_query($Conex, $sql) or die ("Problema de Ejecucion");
   
     mysqli_close($Conex);
  }


  public function Consulta1($geneleg)
  {
     $Conex = $this->Conectando() or die ("Problema de conexion");
     $sql = "select codent, fechaent, causa, nombre, dependientes, genero, nicho 
     from entierros where genero = '$geneleg'";
     $Tabla = mysqli_query($Conex,$sql) or die ("Problema de Ejecucion");
   
     echo "<center><h1>LISTADO DE LOS ENTIERROS</h1></center>";
     echo "<center><h2>GENERO: $geneleg</h2></center>";
     echo "<hr>";
     $this->Titulos();
     while($reg = mysqli_fetch_array($Tabla))
      {
      $this->MostrarRegistro($reg);
      }
     echo "</table>";
     mysqli_close($Conex);
  }

public function Consulta2($caueleg)
  {
     $Conex = $this->Conectando() or die ("Problema de conexion");
     $sql = "select codent, fechaent, causa, nombre, dependientes, genero, nicho from entierros 
     where causa = '$caueleg'";
     $Tabla = mysqli_query($Conex,$sql) or die ("Problema de Ejecucion");
   
     echo "<center><h1>LISTADO DE LOS ENTIERROS</h1></center>";
     echo "<center><h2>CAUSA: $caueleg</h2></center>";
     echo "<hr>";
     $this->Titulos();
     while($reg = mysqli_fetch_array($Tabla))
      {
         $this->MostrarRegistro($reg);
      }
   echo "</table>";
     mysqli_close($Conex);
  }


    }
?>