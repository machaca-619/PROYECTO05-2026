
<?php
include_once("clases1.php");

$obj = new CEMENTERIO();
$obj->Mostrar();
?>