<html>
    <boby>
    <button><A href="/practica_tec/index55.php">HOME</A></button>
    <button><A href="/practica_tec/consultas.php">BACK</A></button>
    <BR><BR>
    </BODY>
</html>

<?php
$geneleg = $_REQUEST["genero"];
//echo $geneleg;

include_once("C:/xampp/htdocs/practica_tec/clases1.php");

$Obj = new CEMENTERIO();
$Obj->Consulta1($geneleg);
?>