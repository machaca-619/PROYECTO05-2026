<html>
<h1><center>ENTIERRO REGISTRADO</center></h1>
<hr>
<?php
$FEnt = $_REQUEST['fechaentierro'];
$Cau = $_REQUEST['causa'];
$Nom = $_REQUEST['nombre'];
$Dep = $_REQUEST['dependientes'];
$Gen = $_REQUEST['genero'];

if(isset($_REQUEST['nicho']))
  $Nic = "SI";
  else
  $Nic = "NO";

/*echo $FEnt."<br>";
echo $Cau."<br>";
echo $Nom."<br>";
echo $Dep."<br>";
echo $Gen."<br>";
echo $Nic."<br>";*/


include_once("C:/xampp/htdocs/practica_tec/clases1.php");

$Obj = new CEMENTERIO();
$Obj->Altas($FEnt, $Cau, $Nom,$Dep,$Gen,$Nic);
$Obj->Mostrar();

echo "<br><br><center><A href='/practica_tec/index55.php'>MENU PRINCIPAL</A></center>";
?>
</html>