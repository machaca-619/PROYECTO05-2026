<?php
include_once("C:/xampp/htdocs/practica_tec/clases1.php");

$Obj = new CEMENTERIO();
$Obj->Mostrar();

echo "<br><br><center><A href='/practica_tec/index55.php'>MENU PRINCIPAL</A></center>";
?>